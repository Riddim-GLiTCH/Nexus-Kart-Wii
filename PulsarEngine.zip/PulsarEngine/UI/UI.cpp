#include <UI/UI.hpp>
#include <PulsarSystem.hpp>
#include <MarioKartWii/UI/Page/RaceHUD/RaceHUD.hpp>
#include <MarioKartWii/Input/InputManager.hpp>

namespace Pulsar {
namespace UI {

void ChangeImage(LayoutUIControl& control, const char* paneName, const char* tplName) {
    TPLPalettePtr tplRes = static_cast<TPLPalettePtr>(control.layout.resources->multiArcResourceAccessor.GetResource(lyt::res::RESOURCETYPE_TEXTURE, tplName));
    if(tplRes != nullptr) control.layout.GetPaneByName(paneName)->GetMaterial()->GetTexMapAry()->ReplaceImage(tplRes);
};

//Implements the use of Pulsar's BMGHolder when needed
enum BMGType {
    BMG_NORMAL,
    CUSTOM_BMG,
    //CUP_TEXT
};
BMGType isCustom;

static int GetMsgIdxByBmgId(const BMGHolder& bmg, s32 bmgId) {
    const BMGMessageIds& msgIds = *bmg.messageIds;
    int ret = -1;
    for(int i = 0; i < msgIds.msgCount; ++i) {
        int curBmgId = msgIds.messageIds[i];
        if(curBmgId == bmgId) {
            ret = i;
            break;
        }
        else if(curBmgId > bmgId) break;
    }
    return ret;
}

static int GetMsgIdxById(const BMGHolder& normalHolder, s32 bmgId) {
    /*
    isCustom = false;
    int ret = GetMsgIdxByBmgId(System::sInstance->GetBMG(), bmgId);
    if(ret < 0) ret = GetMsgIdxByBmgId(normalHolder, bmgId);
    else isCustom = true;
    return ret;
    */
    /*
     if(bmgId >= 0x10000 && bmgId < 0x40000 && CupsConfig::sInstance->HasCupText()) {
         isCustom = CUP_TEXT;
         return bmgId;
     }
     else {
         */
    int ret = GetMsgIdxByBmgId(System::sInstance->GetBMG(), bmgId);
    if(ret < 0) {
        isCustom = BMG_NORMAL;
        ret = GetMsgIdxByBmgId(normalHolder, bmgId);
    }
    else isCustom = CUSTOM_BMG;
    return ret;
    //}
}
kmBranch(0x805f8c88, GetMsgIdxById);

wchar_t* GetMsgByMsgIdx(const BMGHolder& bmg, s32 msgIdx) {
    const BMGInfo& info = *bmg.info;
    if(msgIdx < 0 || msgIdx >= info.msgCount) return nullptr;
    const u32 offset = info.entries[msgIdx].dat1Offset & 0xFFFFFFFE;
    const BMGData& data = *bmg.data;
    return reinterpret_cast<wchar_t*>((u8*)&data + offset);
}

wchar_t* GetMsg(const BMGHolder& normalHolder, s32 msgIdx) {
    wchar_t* ret = nullptr;
    if(isCustom == CUSTOM_BMG) ret = GetMsgByMsgIdx(System::sInstance->GetBMG(), msgIdx);
    if(ret == nullptr) ret = GetMsgByMsgIdx(normalHolder, msgIdx);
    return ret;
}
kmBranch(0x805f8cf0, GetMsg);

const u8* GetFontIndex(const BMGHolder& bmg, s32 msgIdx) {
    const BMGInfo& info = *bmg.info;
    if(msgIdx < 0 || msgIdx >= info.msgCount) return nullptr;
    return &info.entries[msgIdx].font;
};

const u8* GetFont(const BMGHolder& normalHolder, s32 msgIdx) {
    const u8* ret = nullptr;
    if(isCustom == CUSTOM_BMG) ret = GetFontIndex(System::sInstance->GetBMG(), msgIdx);
    if(ret == nullptr) ret = GetFontIndex(normalHolder, msgIdx);
    return ret;
}
kmBranch(0x805f8d2c, GetFont);

const wchar_t* GetCustomMsg(s32 bmgId) {
    const BMGHolder& bmg = System::sInstance->GetBMG();
    return GetMsgByMsgIdx(bmg, GetMsgIdxById(bmg, bmgId));
}

//Live View Shadow Bug Fix
kmWrite32(0x807eb988, 0x807c01c0);
}//namespace UI
}//namespace Pulsar